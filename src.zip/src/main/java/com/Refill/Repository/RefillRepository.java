package com.Refill.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Refill.Main.RefillMain;

public interface RefillRepository extends  JpaRepository<RefillMain,Integer> {

}
