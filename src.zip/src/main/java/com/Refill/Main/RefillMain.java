package com.Refill.Main;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class RefillMain {
	@Id
	private int SId;

	private Date refilldate ;

	private int refillorderid;

	private int refillquantity;

	private String refillstatus;

	public RefillMain() {
		super();
		
	}

	public RefillMain(int sId, Date refilldate, int refillorderid, int refillquantity, String refillstatus) {
		super();
		SId = sId;
		this.refilldate = refilldate;
		this.refillorderid = refillorderid;
		this.refillquantity = refillquantity;
		this.refillstatus = refillstatus;
	}

	public int getSId() {
		return SId;
	}

	public void setSId(int sId) {
		SId = sId;
	}

	public Date getRefilldate() {
		return refilldate;
	}

	public void setRefilldate(Date refilldate) {
		this.refilldate = refilldate;
	}

	public int getRefillorderid() {
		return refillorderid;
	}

	public void setRefillorderid(int refillorderid) {
		this.refillorderid = refillorderid;
	}

	public int getRefillquantity() {
		return refillquantity;
	}

	public void setRefillquantity(int refillquantity) {
		this.refillquantity = refillquantity;
	}

	public String getRefillstatus() {
		return refillstatus;
	}

	public void setRefillstatus(String refillstatus) {
		this.refillstatus = refillstatus;
	} 

}
