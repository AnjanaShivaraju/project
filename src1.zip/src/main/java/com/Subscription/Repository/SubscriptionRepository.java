package com.Subscription.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.Subscription.Main.SubscriptionMain;


public interface SubscriptionRepository extends  JpaRepository<SubscriptionMain,Integer> {

}
