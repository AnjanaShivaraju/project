package com.Subscription.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Subscription.Main.SubscriptionMain;
import com.Subscription.Service.SubscriptionService;


@RequestMapping("/SubscriptionController")

@RestController
public class SubscriptionController {
	@Autowired

	private SubscriptionService service;

	
	
	@PostMapping("/add")

	public SubscriptionMain add(@RequestBody SubscriptionMain subscriptionmain) {

	return service.add(subscriptionmain);

	}
}
