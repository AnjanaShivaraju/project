package com.Subscription.Main;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class SubscriptionMain{
	@Id
	private int  MemberId;
    private Long  InsurencePolicyNumber;
    private String InsurenceProvider;
    private Date Prescriptiondate;
    private int drug_id;
    private String DrugName;
    private String DoctorName;
    private String RefillOccurence;
	public int getMemberId() {
		return MemberId;
	}
	public void setMemberId(int memberId) {
		MemberId = memberId;
	}
	public Long getInsurencePolicyNumber() {
		return InsurencePolicyNumber;
	}
	public void setInsurencePolicyNumber(Long insurencePolicyNumber) {
		InsurencePolicyNumber = insurencePolicyNumber;
	}
	public String getInsurenceProvider() {
		return InsurenceProvider;
	}
	public void setInsurenceProvider(String insurenceProvider) {
		InsurenceProvider = insurenceProvider;
	}
	public Date getPrescriptiondate() {
		return Prescriptiondate;
	}
	public void setPrescriptiondate(Date prescriptiondate) {
		Prescriptiondate = prescriptiondate;
	}
	public int getDrug_id() {
		return drug_id;
	}
	public void setDrug_id(int drug_id) {
		this.drug_id = drug_id;
	}
	public String getDrugName() {
		return DrugName;
	}
	public void setDrugName(String drugName) {
		DrugName = drugName;
	}
	public String getDoctorName() {
		return DoctorName;
	}
	public void setDoctorName(String doctorName) {
		DoctorName = doctorName;
	}
	public String getRefillOccurence() {
		return RefillOccurence;
	}
	public void setRefillOccurence(String refillOccurence) {
		RefillOccurence = refillOccurence;
	}
	public SubscriptionMain(int memberId, Long insurencePolicyNumber, String insurenceProvider, Date prescriptiondate,
			int drug_id, String drugName, String doctorName, String refillOccurence) {
		super();
		MemberId = memberId;
		InsurencePolicyNumber = insurencePolicyNumber;
		InsurenceProvider = insurenceProvider;
		Prescriptiondate = prescriptiondate;
		this.drug_id = drug_id;
		DrugName = drugName;
		DoctorName = doctorName;
		RefillOccurence = refillOccurence;
	}
	public SubscriptionMain() {
		super();
		// TODO Auto-generated constructor stub
	}
    
	
	

}


